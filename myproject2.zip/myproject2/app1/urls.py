from django.urls import path 
from . import views

urlpatterns = [
    path('', views.HomeView.as_view(), name='home'),
    path('login/', views.CustomLoginView.as_view(), name='login'),
    path('logout/', views.CustomLogoutView.as_view(), name='logout'),
    
    # URLs pour les spécialités
    path('specialites/', views.SpecialiteList.as_view(), name='specialite-list'),
    path('specialites/create/', views.SpecialiteCreate.as_view(), name='specialite-create'),
    path('specialites/<int:pk>/update/', views.SpecialiteUpdate.as_view(), name='specialite-update'),
    path('specialites/<int:pk>/delete/', views.SpecialiteDelete.as_view(), name='specialite-delete'),
    
    # URLs pour les étudiants
    path('etudiants/', views.EtudiantList.as_view(), name='etudiant_list'),
    path('etudiants/create/', views.EtudiantCreate.as_view(), name='etudiant_create'),
    path('etudiants/<int:pk>/update/', views.EtudiantUpdate.as_view(), name='etudiant_update'),
    path('etudiants/<int:pk>/delete/', views.EtudiantDelete.as_view(), name='etudiant_delete'),
]