from django.db import models
from django.urls import reverse

class Specialite(models.Model):
    id = models.AutoField(help_text='id de specialite', verbose_name='id de specialite', primary_key=True)
    name = models.CharField(max_length=200, help_text='Nom de specialite', verbose_name='Nom', null=True, blank=True)
    
    def get_absolute_url(self):
        return reverse('specialite-list')

    def __str__(self):
        return self.name

class Etudiant(models.Model):
    GENRE_CHOICES = [
        ('M', 'Masculin'),
        ('F', 'Féminin'),
    ]
    
    id = models.AutoField(help_text='id de l\etudiant', verbose_name='id de l\etudiant', primary_key=True)
    first_name = models.CharField(max_length=200, help_text='Nom de l\etudiant', verbose_name='Nom', null=True, blank=True)
    last_name = models.CharField(max_length=200, help_text='Prénom de l\etudiant', verbose_name='Prénom', null=True, blank=True)
    genre = models.CharField(max_length=1, choices=GENRE_CHOICES, default='M', verbose_name='Genre')
    specialite = models.ForeignKey(Specialite, default=1, on_delete=models.CASCADE)

    def __str__(self):
        return f"{self.first_name} {self.last_name}"

    def get_absolute_url(self):
        return reverse('etudiant_list')

class Reservation(models.Model):
    id = models.AutoField(primary_key=True)
    etudiant = models.ForeignKey(Etudiant, on_delete=models.CASCADE)
    date_reservation = models.DateField()
    heure_debut = models.TimeField()
    heure_fin = models.TimeField()
    motif = models.TextField()
    statut = models.CharField(max_length=20, choices=[
        ('en_attente', 'En attente'),
        ('confirmee', 'Confirmée'),
        ('annulee', 'Annulée')
    ], default='en_attente')

    def __str__(self):
        return f"Réservation de {self.etudiant} le {self.date_reservation}"


