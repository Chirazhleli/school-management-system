from django.shortcuts import render, redirect
from django.views.generic import ListView, CreateView, UpdateView, DeleteView, TemplateView
from django.contrib.auth.views import LoginView, LogoutView
from django.contrib.auth.mixins import LoginRequiredMixin
from django.contrib import messages
from django.urls import reverse_lazy
from .models import Specialite, Etudiant

class CustomLoginView(LoginView):
	template_name = 'app1/login.html'
	redirect_authenticated_user = True
	success_url = reverse_lazy('home')

	def form_valid(self, form):
		messages.success(self.request, 'Vous êtes maintenant connecté.')
		return super().form_valid(form)

	def form_invalid(self, form):
		messages.error(self.request, 'Nom d\'utilisateur ou mot de passe incorrect.')
		return super().form_invalid(form)

	def get_success_url(self):
		next_url = self.request.GET.get('next')
		if next_url:
			return next_url
		return self.success_url

class CustomLogoutView(LogoutView):
	next_page = 'login'

	def dispatch(self, request, *args, **kwargs):
		messages.info(request, 'Vous avez été déconnecté avec succès.')
		return super().dispatch(request, *args, **kwargs)

class HomeView(LoginRequiredMixin, TemplateView):
	template_name = 'app1/index.html'
	login_url = 'login'

class SpecialiteList(LoginRequiredMixin, ListView):
	model = Specialite
	template_name = 'app1/specialite_list.html'
	context_object_name = 'specialites'
	login_url = 'login'

class SpecialiteCreate(LoginRequiredMixin, CreateView):
	model = Specialite
	fields = ['name']
	template_name = 'app1/specialite_form.html'
	success_url = reverse_lazy('specialite-list')
	login_url = 'login'

	def form_valid(self, form):
		messages.success(self.request, 'Spécialité créée avec succès.')
		return super().form_valid(form)

class SpecialiteUpdate(LoginRequiredMixin, UpdateView):
	model = Specialite
	fields = ['name']
	template_name = 'app1/specialite_form.html'
	success_url = reverse_lazy('specialite-list')
	login_url = 'login'

	def form_valid(self, form):
		messages.success(self.request, 'Spécialité mise à jour avec succès.')
		return super().form_valid(form)

class SpecialiteDelete(LoginRequiredMixin, DeleteView):
	model = Specialite
	template_name = 'app1/specialite_confirm_delete.html'
	success_url = reverse_lazy('specialite-list')
	login_url = 'login'

	def delete(self, request, *args, **kwargs):
		messages.success(request, 'Spécialité supprimée avec succès.')
		return super().delete(request, *args, **kwargs)

class EtudiantList(LoginRequiredMixin, ListView):
	model = Etudiant
	template_name = 'app1/etudiant_list.html'
	context_object_name = 'etudiants'
	login_url = 'login'

class EtudiantCreate(LoginRequiredMixin, CreateView):
	model = Etudiant
	fields = ['first_name', 'last_name', 'genre', 'specialite']
	template_name = 'app1/etudiant_form.html'
	success_url = reverse_lazy('etudiant_list')
	login_url = 'login'

	def form_valid(self, form):
		messages.success(self.request, 'Étudiant créé avec succès.')
		return super().form_valid(form)

class EtudiantUpdate(LoginRequiredMixin, UpdateView):
	model = Etudiant
	fields = ['first_name', 'last_name', 'genre', 'specialite']
	template_name = 'app1/etudiant_form.html'
	success_url = reverse_lazy('etudiant_list')
	login_url = 'login'

	def form_valid(self, form):
		messages.success(self.request, 'Étudiant mis à jour avec succès.')
		return super().form_valid(form)

	def form_invalid(self, form):
		messages.error(self.request, 'Le formulaire contient des erreurs.')
		return self.render_to_response(self.get_context_data(form=form))

class EtudiantDelete(LoginRequiredMixin, DeleteView):
	model = Etudiant
	template_name = 'app1/etudiant_confirm_delete.html'
	success_url = reverse_lazy('etudiant_list')
	login_url = 'login'

	def delete(self, request, *args, **kwargs):
		messages.success(request, 'Étudiant supprimé avec succès.')
		return super().delete(request, *args, **kwargs)
