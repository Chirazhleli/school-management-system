// Attendre que le DOM soit chargé
document.addEventListener('DOMContentLoaded', function() {
    // Exemple de fonctionnalité : animation du titre
    const title = document.querySelector('h1');
    if (title) {
        title.style.opacity = '0';
        title.style.transition = 'opacity 1s ease-in-out';
        setTimeout(() => {
            title.style.opacity = '1';
        }, 500);
    }

    // Gestion des messages flash (si vous en avez)
    const messages = document.querySelectorAll('.alert');
    messages.forEach(message => {
        setTimeout(() => {
            message.style.opacity = '0';
            setTimeout(() => {
                message.remove();
            }, 500);
        }, 3000);
    });

    // Ajouter des effets de survol sur les cartes
    const cards = document.querySelectorAll('.card');
    cards.forEach(card => {
        card.addEventListener('mouseenter', function() {
            this.style.transform = 'translateY(-5px)';
            this.style.transition = 'transform 0.3s ease';
        });

        card.addEventListener('mouseleave', function() {
            this.style.transform = 'translateY(0)';
        });
    });
}); 